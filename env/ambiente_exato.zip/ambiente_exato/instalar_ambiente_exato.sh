#!/usr/bin/env bash
# instalar_ambiente_exato.sh -- recria o ambiente Python do LCAD1 (relatório de 2026-10-05):
# Python 3.10.12 + as MESMAS versões do pip freeze (só pacotes do PyPI; os pacotes
# específicos do Ubuntu 22.04 -- apt, dbus, cups, etc. -- não vão pelo pip).
#
# USO (na pasta onde está requirements_exato.txt):
#   bash instalar_ambiente_exato.sh
set -euo pipefail
AQUI="$(cd "$(dirname "$0")" && pwd)"

echo "== 1/5: ferramentas de compilação (algumas versões antigas só vêm como código-fonte) =="
sudo apt-get update -qq
sudo apt-get install -y curl build-essential libspatialindex-dev

echo "== 2/5: uv + Python 3.10.12 =="
command -v uv >/dev/null 2>&1 || { curl -LsSf https://astral.sh/uv/install.sh | sh; }
# shellcheck disable=SC1091
[ -f "$HOME/.local/bin/env" ] && source "$HOME/.local/bin/env"
uv python install 3.10.12

echo "== 3/5: venv ~/venv_tcc (recriado do zero) =="
deactivate 2>/dev/null || true
rm -rf "$HOME/venv_tcc"
uv venv --seed --python 3.10.12 "$HOME/venv_tcc"
# shellcheck disable=SC1091
source "$HOME/venv_tcc/bin/activate"
python --version
pip install --upgrade "pip<25" "setuptools<70" wheel

echo "== 4/5: pacotes que precisam de tratamento especial =="
# PyYAML 5.4.1 quebra com o Cython novo; precisa de Cython<3 sem isolamento de build
pip install "cython<3"
pip install --no-build-isolation PyYAML==5.4.1
# numpy tem que vir antes de quem compila contra ele
pip install numpy==1.21.5
pip install --no-build-isolation Bottleneck==1.3.2

echo "== 5/5: o resto, com as versões exatas =="
# --no-deps: o pip freeze já é o conjunto completo e fixado; o resolvedor recusaria
# combinações que o Ubuntu 22.04 patcheou (ex.: requests 2.25.1 pede idna<3, mas o LCAD1 tinha idna 3.3).
pip install --no-deps -r "$AQUI/requirements_exato.txt"
# cffi não aparece no freeze do LCAD1 mas bcrypt/PyNaCl/cryptography o importam
pip install cffi

echo
echo "== Verificação =="
python --version
pip check || true
pip freeze | sort > /tmp/freeze_novo.txt
echo "Pacotes diferentes do relatório (versão ou ausentes):"
sort "$AQUI/requirements_exato.txt" | sed 's/\r//' > /tmp/freeze_esperado.txt
diff <(tr 'A-Z_' 'a-z-' < /tmp/freeze_esperado.txt) <(tr 'A-Z_' 'a-z-' < /tmp/freeze_novo.txt) | grep '^<' || echo "  nenhum -- tudo igual ao relatório"
