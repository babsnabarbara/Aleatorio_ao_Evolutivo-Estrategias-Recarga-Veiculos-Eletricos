#!/usr/bin/env bash
# setup_sumo.sh -- instala o SUMO do LCAD1 (v1_2_0+0382-3754aed092) neste servidor.
# Pré-requisito: o sumo.tar.gz DE VERDADE (~635 MB), não o ponteiro do Git LFS (134 bytes).
#
# USO:
#   bash setup_sumo.sh [caminho/do/sumo.tar.gz]
# Padrão: ~/Aleatorio_ao_Evolutivo-Estrategias-Recarga-Veiculos-Eletricos/env/env_backup_LCAD1_20261005/sumo.tar.gz
set -euo pipefail

TAR="${1:-$HOME/Aleatorio_ao_Evolutivo-Estrategias-Recarga-Veiculos-Eletricos/env/env_backup_LCAD1_20261005/sumo.tar.gz}"

echo "== 0/4: conferindo o sumo.tar.gz =="
[ -f "$TAR" ] || { echo "ERRO: não achei $TAR"; exit 1; }
TAM=$(stat -c %s "$TAR")
if [ "$TAM" -lt 100000000 ]; then
  echo "ERRO: $TAR tem só $TAM bytes -- é o ponteiro do Git LFS, não o arquivo real."
  echo "      Copie o real de outro servidor, por exemplo:"
  echo "      scp barbara@IP_DO_LCAD3:$TAR $TAR"
  exit 1
fi
gzip -t "$TAR" && echo "   OK ($(du -h "$TAR" | cut -f1))"

echo "== 1/4: bibliotecas de sistema do SUMO =="
sudo apt-get update -qq
sudo apt-get install -y libxerces-c3.2t64 libfox-1.6-0 libopengl0 libglu1-mesa

echo "== 2/4: extraindo em ~/sumo =="
if [ -d "$HOME/sumo" ]; then
  mv "$HOME/sumo" "$HOME/sumo_old_$(date +%Y%m%d%H%M%S)"
  echo "   ~/sumo antigo renomeado"
fi
tar xzf "$TAR" -C "$HOME"

echo "== 3/4: SUMO_HOME e PYTHONPATH no ~/.bashrc =="
if ! grep -q '^export SUMO_HOME=' "$HOME/.bashrc" 2>/dev/null; then
  {
    echo ''
    echo '# SUMO (setup_sumo.sh)'
    echo 'export SUMO_HOME="$HOME/sumo"'
    echo 'export PYTHONPATH="$SUMO_HOME/tools:${PYTHONPATH:-}"'
  } >> "$HOME/.bashrc"
  echo "   adicionado"
else
  echo "   já existe (confira se aponta para ~/sumo)"
fi
export SUMO_HOME="$HOME/sumo"
export PYTHONPATH="$SUMO_HOME/tools:${PYTHONPATH:-}"

echo "== 4/4: verificação =="
FALTA=$(ldd "$SUMO_HOME/bin/sumo" | grep "not found" || true)
if [ -n "$FALTA" ]; then echo "FALTAM bibliotecas:"; echo "$FALTA"; else echo "   libs de sistema: OK"; fi
"$SUMO_HOME/bin/sumo" --version | head -1
echo "Esperado: Eclipse SUMO Version v1_2_0+0382-3754aed092"
echo
echo "Abra um terminal novo (ou: source ~/.bashrc) para o SUMO_HOME valer."
